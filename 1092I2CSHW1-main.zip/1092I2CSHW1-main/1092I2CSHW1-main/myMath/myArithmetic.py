''' myArithmetic '''
def myAdd(x, y):
    return x + y

def mySub(x, y):
    return x -y

def myMultiply(x, y):
    return x*y

def myDiv(x, y):
    if y != 0:
        return x/y
    else:
        return False

